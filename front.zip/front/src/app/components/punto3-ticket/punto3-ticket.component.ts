import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Ticket } from '../../model/ticket';
import { TicketService } from '../../services/ticket.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-punto3-ticket',
  templateUrl: './punto3-ticket.component.html',
  standalone: true,
  imports: [FormsModule, CommonModule],
  styleUrls: ['./punto3-ticket.component.css']
})
export class Punto3TicketComponent implements OnInit {

  tickets: Ticket[] = [];
  categoriaEspectador: string = "";
  categoriasEspectador: string[] = ['l', 'e'];

  constructor(private apiService: TicketService, private router: Router) {
    this.categoriaEspectador = "";
  }

  ngOnInit() {
    this.obtenerTickets();
  }

  obtenerTickets() {
    this.apiService.getTickets().subscribe(
      data => {
        this.tickets = data;
        this.filtrarPorCategoria(this.categoriaEspectador); // Filtrar al obtener los tickets
      },
      error => {
        console.log(error);
      }
    );
  }

  filtrarPorCategoria(categoria: string) {
    if (categoria === "") {
      this.tickets = this.tickets; // Mostrar todos si no hay categoría seleccionada
    } else {
      this.tickets = this.tickets.filter(ticket => ticket.categoriaEspectador === categoria);
    }
  }
  borrarTicket(ticket: Ticket) {
    this.apiService.deleteTicket(ticket._id).subscribe(
      result => {
        if (result.status === 1) {
          alert(result.msg);
          // Refrescar lista de tickets después de eliminar
          this.tickets = this.tickets.filter(t => t._id !== ticket._id);
        }
      },
      error => {
        console.error('Error al borrar el ticket:', error);
        alert('Error al borrar el ticket.');
      }
    );
  }

  agregarTicket() {
    this.router.navigate(["punto3form", 0]);
  }

  modificarTicket(ticket: Ticket) {
    this.router.navigate(["punto3form", ticket._id]);
  }

  cambiarCategoria(categoria: string) {
    this.categoriaEspectador = categoria;
    this.filtrarPorCategoria(categoria);
  }
}
