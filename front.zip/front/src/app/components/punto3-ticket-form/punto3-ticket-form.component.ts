import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Espectador } from '../../model/espectador';
import { Ticket } from '../../model/ticket';
import { EspectadorService } from '../../services/espectador.service';
import { TicketService } from '../../services/ticket.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-punto3-ticket-form',
  templateUrl: './punto3-ticket-form.component.html',
  standalone: true,
  imports: [FormsModule, CommonModule],
  styleUrls: ['./punto3-ticket-form.component.css']
})
export class Punto3TicketFormComponent implements OnInit {
  espectador: Espectador[] = [];
  ticket: Ticket = new Ticket();
  accion: string = "";

  constructor(
    private apiService: TicketService,
    private activateRoute: ActivatedRoute,
    private espectadorService: EspectadorService,
    private router: Router
  ) {
    const fecha = new Date();
    this.ticket.fechaCompra = fecha.toLocaleDateString();
  }

  ngOnInit(): void {
    this.activateRoute.params.subscribe(params => {
      if (params['id'] === '0') {
        this.accion = "new";
        this.cargarEspectadores();
      } else {
        this.accion = "update";
        this.cargarEspectadores();
        this.cargarTicket(params['id']);
      }
    });
  }

  cargarTicket(id: string) {
    this.apiService.getTicket(id).subscribe(
      result => {
        console.log(result);
        this.ticket = result; // Asignar el ticket recibido del servicio
        // Encontrar el espectador correspondiente y asignarlo al ticket
        this.ticket.espectador = this.espectador.find(e => e._id === this.ticket.espectador._id)!;
      },
      error => {
        console.error('Error al cargar el ticket:', error);
      }
    );
  }

  cargarEspectadores() {
    this.espectadorService.getEspectadores().subscribe(
      result => {
        console.log(result);
        this.espectador = result; // Asignar el array de espectadores recibido del servicio
      },
      error => {
        console.error('Error al cargar los espectadores:', error);
      }
    );
  }

  guardarTicket() {
    this.apiService.createTicket(this.ticket).subscribe(
      result => {
        if (result.status === 1) {
          alert(result.msg);
        } this.router.navigate(["punto3"])

      },
      error => {
        console.error('Error al guardar el ticket:', error);
        alert('Error al guardar el ticket.');
      }
    );
  }

  modificarTicket() {
    console.log(this.ticket);
    this.apiService.editTicket(this.ticket).subscribe(
      result => {
        if (result.status === 1) {
          alert(result.msg);
          this.router.navigate(["punto3"]);
        } 
      },
      error => {
        console.error('Error al modificar el ticket:', error);
        alert('Error al modificar el ticket.');
      }
    );
  }

  volverAtras() {
    this.router.navigate(["punto3"]);
  }
}
