import { Punto1 } from './punto1';

describe('Punto1', () => {
  it('should create an instance', () => {
    expect(new Punto1()).toBeTruthy();
  });
});
