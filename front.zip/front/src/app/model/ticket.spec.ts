import { Ticket } from './ticket';

describe('Ticket', () => {
  it('should create an instance', () => {
    expect(new Ticket()).toBeTruthy();
  });
});
