import { Espectador } from './espectador';

describe('Espectador', () => {
  it('should create an instance', () => {
    expect(new Espectador()).toBeTruthy();
  });
});
