import { Punto2 } from './punto2';

describe('Punto2', () => {
  it('should create an instance', () => {
    expect(new Punto2()).toBeTruthy();
  });
});
