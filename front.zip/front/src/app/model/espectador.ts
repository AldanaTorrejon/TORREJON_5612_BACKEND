export class Espectador {
  _id!:string;
  apellido!:string;
  nombre!: string;
  dni!:string;
  email!: string;
}
